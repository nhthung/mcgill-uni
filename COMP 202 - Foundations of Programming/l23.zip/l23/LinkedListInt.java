public class LinkedListInt {
  private int val;
  private LinkedListInt next;
  
  // constructor with a null next
  public LinkedListInt(int val) {
    this.val = val;
    this.next = null;
  }
  
  public LinkedListInt(int val, LinkedListInt next) {
    this.val = val;
    this.next = next;
  }
  
  // set the next element
  public void setNext(LinkedListInt next) {
    this.next = next;
  }
  
  // override the default toString() method
  public String toString() {
    if (this.next == null) {
      return this.val + "";
    }
    return this.val + ", " + this.next.toString();
  }
  
  // append tail to the end of this list
  public void append(LinkedListInt tail) {
    if (this.next == null) {
      // at the end: set next
      this.next = tail;
    }
    else {
      // not at the end: keep searching
      this.next.append(tail);
    }
  }
  
  // set the element at a certain position
  public void setElement(int index, int val) {
    if (index == 0) {
      this.val = val;
    }
    else {
      this.next.setElement(index - 1, val);
    }
  }
  
  /* Doesn't work for removing the very first element!
   * You could write another version which returns a reference
   * to the first element of the LinkedListInt, which would then
   * work.
   */
  public int removeElement(int index) {
    return this.removeElement(index, null);
  }
  
  public int removeElement(int index, LinkedListInt prev) {
    if (index == 0) {
      if (prev != null) {
        prev.next = this.next;
      }
      return this.val;
    }
    else {
      return this.next.removeElement(index - 1, this);
    }
  }
  
  /**
   * Return the index of val in the LinkedListInt, or
   * -1 if not found.
   */
  public int find(int val) {
    if (this.val == val) {
      // found; indicate that it is here
      return 0;
    }
    else if (this.next == null) {
      // not in the list
      return -1;
    }
    else {
      // recursive case: call on rest of list
      int result = this.next.find(val);
      if (result < 0) { 
        // pass on the fact that it is not in the list
        return -1;
      }
      else {
        // add one to the distance and return to caller
        return result + 1;
      }
    }
  }
  
  public static void main(String[] args) {
    LinkedListInt el3 = new LinkedListInt(3);
    LinkedListInt el2 = new LinkedListInt(2, el3);
    LinkedListInt el1 = new LinkedListInt(1, el2);
    
    System.out.println(el1);
    // adding element to the end of the list
    LinkedListInt el5 = new LinkedListInt(5);
    LinkedListInt el4 = new LinkedListInt(4, el5);
    
    el1.append(el4);
    System.out.println(el1);
    el1.setElement(2, -1);
    System.out.println(el1);
    
    el1.removeElement(1);
    System.out.println(el1);
    
    System.out.println(el1.find(6));
  }
  
}