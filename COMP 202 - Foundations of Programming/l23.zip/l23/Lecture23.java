public class Lecture23 {
  public static void main(String[] args) {
    int[] arr = {4, 3, 2};
    
    printArray(arr);
  }
  
  public static void printArray(int[] arr) {
    printArray(arr, 0);
  }
  
  public static void printArray(int[] arr, int start) {
    if (start == arr.length - 1) {
      // base case: last element
      System.out.println(arr[start]);
    }
    else {
      // print current element
      System.out.print(arr[start] + ", ");
      // recursive step: print rest of the array
      printArray(arr, start + 1);
    }
  }
}




