public class MathTest {
  public static void main(String[] args) {
    double result;
    // test computeAreaCircle
    result = computeAreaCircle(1.0);
    System.out.println(result);
    result = computeAreaCircle(2.0);
    System.out.println(result);
    // test cube
    System.out.println(cube(0.0)); // expect 0.0
    System.out.println(cube(1.0)); // expect 1.0
    System.out.println(cube(-1.0)); // expect -1.0
    System.out.println(cube(3.0)); // expect 27.0
    
    // test computeVolumeSphere
    System.out.println(computeVolumeSphere(1.0));
    System.out.println(computeVolumeSphere(2.0));
    System.out.println(computeVolumeSphere(3.0));
  }
  
  public static double computeAreaCircle(double r) {
    // compute the area of a circle with radius r
    double area = Math.PI * r * r;
    return area;
  }
  
  public static double computeVolumeSphere(double r) {
    // compute the volume of a sphere with radius r
    // note that this method calls another method that we defined
    // also note that the variable r in this method is different and
    // separate from the r in computeAreaCircle
    return 4.0 / 3.0 * Math.PI * cube(r);
  }
  
  public static double cube(double x) {
    // compute x cubed. i.e., x^3
    return x * x * x;
  }
  
}