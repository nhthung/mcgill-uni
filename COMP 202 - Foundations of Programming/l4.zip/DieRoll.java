public class DieRoll {
  public static void main(String[] args) {
    // should print out 5 different numbers each time the program is run
    System.out.println(roll());
    System.out.println(roll());
    System.out.println(roll());
    System.out.println(roll());
    System.out.println(roll());
  }
  
  public static double roll() {
    // return a random double from {1.0, 2.0, 3.0, 4.0, 5.0, 6.0}
    return Math.ceil(Math.random() * 6.0);
  }
}