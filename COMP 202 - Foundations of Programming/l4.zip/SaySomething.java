public class SaySomething {
  public static void main(String[] args) {
    // call sayGreeting here
    String s1 = "Jackie";
    String s2 = "COMP-202";
    sayGreeting(s1, s2);
    
    sayGreeting(s2, s1);
  }
  
  //define sayGreeting here
  public static void sayGreeting(String speaker, String listener) {
    System.out.println(speaker + " says hello to " + listener);
  }
}