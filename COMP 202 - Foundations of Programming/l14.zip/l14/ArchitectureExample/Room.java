public class Room {
  private String name;
  private double sizeSqFt;
  
  public Room(String name, double area) {
    this.name = name;
    this.sizeSqFt = area;
  }
}