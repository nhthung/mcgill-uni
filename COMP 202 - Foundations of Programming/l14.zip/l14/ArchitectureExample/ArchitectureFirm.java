public class ArchitectureFirm {
  public static void main(String[] args) {
    Room someRoom = new Room("LEA 219", 800.0);
    Building someBuilding = 
      new Building("Leacock", 15, 10000.0);
  }
}