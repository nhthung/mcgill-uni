public class Building {
  private double sizeSqFt;
  private String name;
  private Room[] rooms;
  
  public Building(String name, int nRooms, 
                  double area) {
    this.name = name;
    this.sizeSqFt = area;
    this.rooms = new Room[nRooms];
  }
}