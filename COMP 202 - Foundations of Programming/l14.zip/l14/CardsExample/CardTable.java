public class CardTable {
  
  // Test the Card and Deck classes
  public static void main(String[] args) {
    Deck.printNumberOfDecks(); // check that this is 0
    Deck deck = new Deck();
    Deck.printNumberOfDecks(); // check that this is 1
    
    System.out.println();
    
    deck.shuffle();
    // should be three different cards each time
    Card c = deck.drawCard();
    c.printCard();
    c = deck.drawCard();
    c.printCard();
    c = deck.drawCard();
    c.printCard();
    
    new Deck();
    new Deck();
    new Deck();
    new Deck();
    new Deck();
    Deck.printNumberOfDecks(); // check that this is 6
  }
}




