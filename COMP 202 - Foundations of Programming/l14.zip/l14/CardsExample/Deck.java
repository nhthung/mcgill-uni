import java.util.*;

public class Deck {
  private Card[] cards;
  private int topOfDeck;
  public static String[] suits = {"Spades", "Clubs", 
    "Diamonds", "Hearts"};
  private static int numberCreated = 0;
  
  // constructor
  public Deck() {
    this.cards = new Card[52];
    this.topOfDeck = 0;
    numberCreated++;
    int i = 0;
    for (int j = 0; j < suits.length; j++) {
      for (int rank = 1; rank <=13; rank++) {
        this.cards[i] = new Card(rank, suits[j]);
        i++;
        //System.out.println("Creating " + rank + 
        //                   " of " + suits[j]);
      }
    }
  }
  
  // Return the top card of the deck
  public Card drawCard() {
    Card topCard = this.cards[this.topOfDeck];
    this.topOfDeck++;
    return topCard;
  }
  
  // Randomly shuffle the order of the cards
  public void shuffle() {
    Collections.shuffle(
        Arrays.asList(this.cards));
  }
  
  // Print the total number of Deck objects created
  public static void printNumberOfDecks() {
    System.out.println(numberCreated);
  }
}




