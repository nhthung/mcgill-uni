public class Card {
  // 1 - Ace, 11 - Jack, 12 - Queen, 13 - King
  private int rank; 
  
  // Spades, Clubs, Diamonds, Hearts
  private String suit;
  
  // constructor
  public Card(int rank, String suit) {
    this.rank = rank;
    this.suit = suit;
  }
  
  // Print out which card this is
  public void printCard() {
    System.out.println(this.rank + " of " +
                       this.suit);
  }
}





