public class Swap {
  public static void main(String[] args) {
    int x = 5;
    int y = 4;
    int a = x; // temporary variable
    x = y;
    y = a;
    // print out results
    System.out.println(x);
    System.out.println(y);
  }
}