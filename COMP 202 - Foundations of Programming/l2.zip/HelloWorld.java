public class HelloWorld {
  public static void main(String[] args) {
    System.out.println("Hello, World!");
    System.out.println("I'm excited to be learning how to program.");
    System.out.println("You'll see what I'll be able to do!");
  }
}