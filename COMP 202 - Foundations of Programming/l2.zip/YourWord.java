public class YourWord {
  public static void main(String[] args) {
    // Note: be sure to run in Interactions pane using "run YourWord someword", rather than htting the Run button.
    String s = args[0]; // store first word in a variable
    System.out.println("Your word is " + s);
  }
}