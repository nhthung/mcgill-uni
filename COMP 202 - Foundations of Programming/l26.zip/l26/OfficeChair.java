public class OfficeChair {
  private int height;
  public static final int minHeight = 50;
  public static final int maxHeight = 100;
  
  public OfficeChair() {
    this.height = 75;
  }
  
  public int getHeight() {
    return this.height;
  }
  
  public void setHeight(int newHeight) {
    // make sure new height is within safety bounds
    if (newHeight < minHeight) {
      newHeight = minHeight;
    }
    if (newHeight > maxHeight) {
      newHeight = maxHeight;
    }
    this.height = newHeight;
  }
}




