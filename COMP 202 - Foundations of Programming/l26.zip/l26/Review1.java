/*
 *  Exactly one
 *  (( a && !b && !c) ||
 *   (!a &&  b && !c) ||
 *   (!a && !b &&  c))
 * 
 *  Exactly two
 *  ((!a &&  b &&  c) ||
 *   ( a && !b &&  c) ||
 *   ( a &&  b && !c))
 * 
 */