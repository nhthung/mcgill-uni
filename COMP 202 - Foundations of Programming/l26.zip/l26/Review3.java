import java.util.*;
public class Review3 {
  public static boolean sameLetters(String s1, String s2) {
    HashSet<Character> set1 = new HashSet<Character>();
    for (int i = 0; i < s1.length(); i++) {
      set1.add(s1.charAt(i));
    }
    
    HashSet<Character> set2 = new HashSet<Character>();
    for (int i = 0; i < s2.length(); i++) {
      set2.add(s2.charAt(i));
    }
    
    return set1.equals(set2);
  }
  
  public static void main(String[] args) {
    System.out.println(sameLetters("that", "hat"));
  }
}