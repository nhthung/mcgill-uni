public class Review4 {
  public static int squareRec(int x) {
    if (x == 0) {
      return 0;
    }
    return squareRec(x - 1) + 2 * x - 1;
  }
  
  public static void main(String[] args) {
    System.out.println(squareRec(0));
    System.out.println(squareRec(5));
  }

}

