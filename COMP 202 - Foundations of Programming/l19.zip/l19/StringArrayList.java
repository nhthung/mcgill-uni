/* Our own implementation of ArrayList<String>! */
public class StringArrayList {
  private String[] data;
  private int numElements;
  
  public StringArrayList() {
    this.data = new String[5];
    this.numElements = 0;
  }

  /*
   * Return the size of the array.
   */
  public int size() {
    return this.numElements;
  }
  
  /*
   * Helper method that doubles the capacity of this.data
   */
  private void expandCapacity() {
    String[] newArray = new String[this.data.length * 2];    
    for (int i = 0; i < this.data.length; i++) {
      newArray[i] = this.data[i];
    }
    this.data = newArray;
  }
  
  /*
   * Add an element to the end of the ArrayListString
   */
  public void add(String el) {
    // expand capacity if this.data is full
    if (this.numElements >= this.data.length) {
      expandCapacity();
    }
    this.data[this.numElements] = el;
    this.numElements++;
  }
  
  /*
   * Add an element at the specified index
   */
  public void add(String el, int index) {
    // assume index between 0 and size
    // add at a specific position
    if (this.numElements >= this.data.length) {
      expandCapacity();
    }
    // shift things forward by one, going backwards
    for (int i = this.numElements; i > index; i--) {
      this.data[i] = this.data[i - 1];
    }
    this.data[index] = el;
    this.numElements++;
  }
  
  /*
   * Get the element at position index.
   */
  public String get(int index) {
    if (index < 0 || index >= this.numElements) {
      return null;
    }
    return this.data[index];
  }
  
  /*
   * Find the first occurrence of target in the StringArrayList,
   * return -1 if not found.
   */
  public int indexOf(String target) {
    int index = -1;
    for (int i = 0; i < this.numElements; i++) {
      if (target.equals(this.data[i])) {
        return i;
      }
    }
    return index;
  }
  
  /*
   * Remove the String at the specified position and return it.
   */
  public String remove(int index) {
    // assume index is between 0 and numElements - 1
    String toReturn = this.data[index];
    for (int i = index; i < this.numElements - 1; i++) {
      this.data[i] = this.data[i + 1];
    }
    this.numElements--;
    return toReturn;
  }
  
  /*
   * Remove the first occurrence of a given String
   */
  public String remove(String toRemove) {
    // trick 1: use our previously written code to help us!
    int position = indexOf(toRemove);
    if (position == -1) {
      // not found
      return null;
    }
    // trick 2: use our previously written code to help us!
    return remove(position);
  }
}





