public class Driver {
  public static void main(String[] args) {
    StringArrayList arrList = new StringArrayList();
    // test adding to capacity
    arrList.add("1");
    arrList.add("2");
    arrList.add("3");
    arrList.add("4");
    arrList.add("5");
    
    printArrList(arrList);
    
    // test adding over capacity
    arrList.add("6");
    
    printArrList(arrList);
    
    // test adding at specified positions
    arrList.add("Hi", 2);
    arrList.add("Bye", 7);
    
    printArrList(arrList);
    
    // test finding elements in array
    System.out.println(arrList.indexOf("3"));
    System.out.println(arrList.indexOf("7"));
   
    // test removing at a specified position
    arrList.remove(1);
    
    printArrList(arrList);
    
    // test removing a particular String
    arrList.remove("Bye");
    
    printArrList(arrList);
  }
  
  // helper method to print array list
  private static void printArrList(StringArrayList arrList) {
    for (int i = 0; i < arrList.size(); i++) {
      System.out.print(arrList.get(i) + " ");
    }
    System.out.println();
  }
  
}