import java.util.*;
public class City {
  private String name;
  private int population;
  private String mayor;
  
  public City(String name, int pop) {
    this.name = name;
    this.population = pop;
  }
  
  public static void main(String[] args) {
    // store City references by name
    HashMap<String,City> map = new HashMap<String,City>();
    City c1 = new City("Montreal", 4000000);
    map.put(c1.name, c1);
    
    c1 = new City("Toronto", 10000000);
    map.put(c1.name, c1);
    
    c1 = new City("Dubai", 500000);
    map.put(c1.name, c1);
    
    // interactive query
    Scanner sc = new Scanner(System.in);
    System.out.println("Which city would you like to look up?");
    String cityName = sc.nextLine();
    City c = map.get(cityName);
    if (c != null) {
      System.out.println(c.name + " has a population of " +
                       c.population);
    }
    else {
      System.out.println(cityName + " is not in our database.");
    }
  }
}









