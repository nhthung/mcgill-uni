public class Player {
  // fields
  private String name;
  private int grenades;
  private double xLoc;
  private double yLoc;
  private double zLoc;
  private double life;
  /*
A method that prints "BOOM!" and decreases the 
grenade stock by 1
   */ 
  // constructor
  public Player(String myName) {
    this.life = 100.0;
    this.name = myName;
    this.xLoc = 0.0;
    this.yLoc = 0.0;
    this.zLoc = 0.0;
    this.grenades = 5;
    System.out.println("New player, " + this.name
                         + ", created.");
  }
  
  public void addGrenades(int amount) {
    this.grenades += amount;
  }
  
  public void printGrenadesLeft() {
    System.out.println(this.grenades);
  }
  
  public void useGrenade() {
    this.grenades--;
    System.out.println("BOOM!");
  }
  
  public void printName() {
    System.out.println(this.name);
  }
}





