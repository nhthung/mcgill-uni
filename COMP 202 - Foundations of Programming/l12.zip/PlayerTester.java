public class PlayerTester {
  public static void main(String[] args) {
  // use code that we wrote
    Player p;
    p = new Player("Jackie");
    Player p2;
    p2 = new Player("Bob");
    
    p.printGrenadesLeft();
    p.useGrenade();
    p.printGrenadesLeft();
    p2.addGrenades(10);
    p2.printGrenadesLeft();
    p2.useGrenade();
    p2.printGrenadesLeft();
    p2.useGrenade();
    p2.printGrenadesLeft();
  }
}