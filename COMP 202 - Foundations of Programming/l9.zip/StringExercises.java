public class StringExercises {
  public static void main(String[] args) {
    System.out.println(toNameFormat("bOb"));
    System.out.println(toNameFormat("BOb"));
    System.out.println(toNameFormat("BOB"));
    System.out.println(toNameFormat("Bob"));
  }
  
  /**
   * This version uses loops.
   */
  public static String toNameFormat(String a) {
    String b = "";
    // Note differences between a String and a char[]
    for (int i = 0; i < a.length(); i++) {
      char myChar = a.charAt(i);
      if (i == 0) {
        b += Character.toUpperCase(myChar);
      }
      else {
        b += Character.toLowerCase(myChar);
      }
    }
    return b;
  }
  
  /**
   * This version does not use loops.
   */
  public static String toNameFormat2(String a) {
    String b = "";
    if (a.length() > 0) {
      b += Character.toUpperCase(a.charAt(0));
      b += a.substring(1).toLowerCase();
    }
    return b;
  }
  
}