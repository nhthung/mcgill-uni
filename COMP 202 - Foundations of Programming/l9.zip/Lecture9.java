public class Lecture9 {
  public static void main(String[] args) {
    int[] arr1 = {1, 4, 3, 6, 7};
    printArray(arr1);
    
    // code that does the copying
    int[] arr2 = new int[arr1.length];
    for (int i = 0; i < arr1.length; i++) {
      arr2[i] = arr1[i];
    }
  
    // verify that we've copied the array correctly
    printArray(arr2);
    System.out.println(arr1 == arr2); // should print false
  }
  
  // method to print out the elements in an array
  public static void printArray(int[] arr) {
    for (int i = 0; i < arr.length; i++) {
      System.out.print(arr[i]);
      if (i < arr.length - 1) {
        System.out.print(", ");
      }
    }
    System.out.println();
  }
}




