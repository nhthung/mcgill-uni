public class Lecture5 {
  public static void main(String[] args) {
    // example of order of operations; try out the other examples from the slides!
    int x = 1 / 2 + 1 / 2;
    System.out.println(x);
    
    // examples of calling methods that are not static
    System.out.println("Abc".equals("Abc"));
    System.out.println("Abc".equalsIgnoreCase("ABC"));
    
    String lower = "ABC".toLowerCase();
    System.out.println(lower);
  }
}