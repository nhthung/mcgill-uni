public class CheckWord {
  public static void main(String[] args) {
    // Testing code--pass input using Interactions pane
    String word = args[0];
    String prefix = args[1];
    String suffix = args[2];
    System.out.println(checkPrefixSuffix(word, prefix, suffix));
  }
  
  /*
   * Returns true iff word starts with prefix and ends with suffix.
   */
  public static boolean checkPrefixSuffix(String word, String prefix, 
                                          String suffix) {
    boolean result = word.startsWith(prefix) && word.endsWith(suffix);
    return result;
  }
}



