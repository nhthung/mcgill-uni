import java.util.*;
public class CosineCalculator {
  public static void main(String[] args) {
    // print out each vector
    HashMap<String, Integer> v1 = new HashMap<String, Integer>();
    v1.put("cat", 1);
    v1.put("dog", 4);
    System.out.println(v1);
    
    HashMap<String, Integer> v2 = new HashMap<String, Integer>();
    v2.put("cat", 5);
    v2.put("dog", 2);
    System.out.println(v2);
    /*
    System.out.println(dotProduct(v1, v2));
    System.out.println(norm(v1));
    System.out.println(norm(v2));
    */
    // print out cosine similarity
    System.out.println(cosine(v1, v2));
  }
  
  /*
   * Return the cosine similarity between two vectors stored using
   * HashMap<String, Integer>
   */
  public static double cosine(HashMap<String, Integer> v1,
                              HashMap<String, Integer> v2) {
    return dotProduct(v1, v2) / (norm(v1) * norm(v2));
  }
  
  /*
   * Return the vector norm of v
   * i.e., the length of the vector, |v|
   */
  public static double norm(HashMap<String, Integer> v) {
    double sumValues = 0.0;
    for (String c: v.keySet()) {
      double val = v.get(c);
      sumValues += val * val;
    }
    return Math.sqrt(sumValues);
  }
  
  /*
   * Return the dot product between v1 and v2
   */
  public static double dotProduct(HashMap<String, Integer> v1,
                                  HashMap<String, Integer> v2) {
    double sumValues = 0.0;
    for (String c: v1.keySet()) {
      double val1 = v1.get(c);
      if (v2.containsKey(c)) {
        double val2 = v2.get(c);
        sumValues += val1 * val2;
      }
    }
    return sumValues;
  }
}