public class EditDistance {
  public static void main(String[] args) {
    String a = args[0];
    String b = args[1];
    
    System.out.println(dist(a,b));
  }
  
  /*
   * Return Levenshtein edit distance between
   * a and b.
   */
  public static int dist(String a, String b) {
    // base cases
    if (a.equals(b)) {
      return 0;
    }
    if (a.length() == 0) {
      // a is empty
      return b.length();
    }
    if (b.length() == 0) {
      // b is empty
      return a.length();
    }
    
    // recursive cases
    // subcase 1: first letter of a and b are equal
    if (a.charAt(0) == b.charAt(0)) {
      return dist(a.substring(1), b.substring(1));
    }
    // subcase 2: first letter of a and b are different
    else {
      return 1 + min(
          dist(a.substring(1), b),
          dist(a, b.substring(1)),
          dist(a.substring(1), b.substring(1)));
    }
  }
  
  // find minimum between three ints
  public static int min(int a, int b, int c) {
    return Math.min(Math.min(a, b), c);
  }
}
