import java.util.Scanner;
public class TicTacToe {
  public static void main(String[] args) {
    // Start game
    char[] board = createBoard();
    Scanner sc = new Scanner(System.in);
    char nextPlayer = 'X';
    boolean gameEnded = false;
    printBoard(board);
    // main game loop
    while (!gameEnded) {
      // Get the current player's next move
      int nextMove = getNextMove(sc, nextPlayer, board);
      // Apply the result of the move
      applyMove(nextMove, board, nextPlayer);
      if (nextPlayer == 'X') {
        nextPlayer = 'O';
      }
      else {
        nextPlayer = 'X';
      }
      printBoard(board);
      // Check whether game has ended
      char result = checkGameEnd(board);
      if (result == 'X' || result == 'O') {
        System.out.println(result + " has won!");
        gameEnded = true;
      }
      else if (result == '-') {
        System.out.println("Game drawn.");
        gameEnded = true;
      }
    }
  }
  
  /*
   * Create a new empty 3x3 game board.
   */
  public static char[] createBoard() {
    char[] board = new char[9];
    for (int i = 0; i < board.length; i++) {
      board[i] = ' ';
    }
    return board;
  }
  
  /*
   * 'X' - X wins
   * 'O' - O wins
   * ' ' - game continues
   * '-' - draw game
   */
  public static char checkGameEnd(char[] board) {
    // check if somebody's won
    // horizontal
    if ((board[0] == board[1]) && (board[1] == board[2]) 
        && (board[0] != ' '))
      return board[0];
    if ((board[3] == board[4]) && (board[4] == board[5]) 
        && (board[3] != ' '))
      return board[3];
    if ((board[6] == board[7]) && (board[7] == board[8]) 
        && (board[6] != ' '))
      return board[6];
    
    // vertical
    if ((board[0] == board[3]) && (board[3] == board[6]) 
        && (board[0] != ' '))
      return board[0];
    if ((board[1] == board[4]) && (board[4] == board[7]) 
        && (board[1] != ' '))
      return board[1];
    if ((board[2] == board[5]) && (board[5] == board[8]) 
        && (board[2] != ' '))
      return board[2]; 
    
    // diagonals
    if ((board[0] == board[4]) && (board[4] == board[8]) 
        && (board[0] != ' '))
      return board[0];
    if ((board[2] == board[4]) && (board[4] == board[6]) 
        && (board[2] != ' '))
      return board[2];
    
    // check if board is full
    boolean fullBoard = true;
    for (int i = 0; i < board.length; i++) {
      if (board[i] == ' ')
        fullBoard = false;
    }
    if (fullBoard)
      return '-';
    
    // game continues otherwise
    return ' ';
  }
  
  /*
   * Get the next move from the user.
   */
  public static int getNextMove(Scanner sc, char nextPlayer, 
                                char[] board) {
    boolean isValid = false;
    int move = -1;
    // loop until a valid move is entered
    while (!isValid) {
      System.out.println("It's " + nextPlayer + "'s turn! Enter your move: ");
      move = sc.nextInt();
      isValid = (move >= 0 && move <= 8 && board[move] == ' ');
    }
    return move;
  }
  
  /*
   * Update the board with the new move.
   */
  public static void applyMove(int nextMove, char[] board, 
                               char nextPlayer) {
    board[nextMove] = nextPlayer;
  }
  
  /*
   * Print out state of the board.
   */
  public static void printBoard(char[] board) {
    // rowOffset tells us which row it is (0,1,2), (3,4,5), or (6,7,8)
    for (int rowOffset = 0; rowOffset <= 6; rowOffset += 3) {
      for (int i = 0; i < 3; i++) {
        System.out.print(i + rowOffset + ": " + 
                         board[i + rowOffset] + " |");
      }
      System.out.println();
    }
  }
}