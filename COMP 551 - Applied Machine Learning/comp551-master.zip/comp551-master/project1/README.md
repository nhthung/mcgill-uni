# Project 1

Predicting popularity of Reddit comments using linear regression.

See `requirements.txt` for required packages.
