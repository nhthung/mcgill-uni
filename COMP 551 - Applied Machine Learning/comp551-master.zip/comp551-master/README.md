# comp551

[![Codacy Badge](https://api.codacy.com/project/badge/Grade/44db6e35bf014c72a43e201ce83991c3)](https://app.codacy.com/app/alexH2456/comp551?utm_source=github.com&utm_medium=referral&utm_content=theGirrafish/comp551&utm_campaign=Badge_Grade_Dashboard)

All files related to COMP 551.
