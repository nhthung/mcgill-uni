# COMP 551 Project 1

### Members: Le Nhat Hung, Negin Ashouri, Sidi Yang

## Usage

A Makefile with commands is included to make running scripts easier.  
To make use of it, or just to be able run scripts with with expected outcomes, **please make sure the project's structure is kept as follow:**

    ├── Makefile           <- Makefile with commands like `make data` or `make train`
    ├── README.md          
    ├── data
    │   └── raw            <- The original, immutable data dump.
    │
    ├── notebooks          <- Jupyter notebooks.
    │
    ├── requirements.txt   <- The requirements file for reproducing the analysis environment, e.g.
    │                         generated with `pip freeze > requirements.txt`
    │
    └── src                <- Source code for use in this project.
        ├── __init__.py    <- Makes src a Python module
        │
        ├── data           <- Scripts to generate data
        │   └── make_dataset.py
        │
        ├── features       <- Scripts to turn raw data into features for modeling
        │   └── build_features.py
        │
        └── models         <- Scripts to train models and then use trained models to make
            │                 predictions
            ├── models.py
            ├── predict_model.py
            └── train_model.py

### Installing required packages

    make requirements

### Building the datasets and features

    # Create 3 .json datasets in data/processed/ from the raw dataset in data/raw/
    make data

    # Create files storing X_counts and y in src/features/ from the datasets in data/processed/
    make features

### Training models

    # Check environment requirements, build datasets and features,
    # then run src/models/train_model.py to train and save models to models/
    make train

### Make predictions
Predictions are json lists in `reports/`.  
Make predicions with:

    make predict
