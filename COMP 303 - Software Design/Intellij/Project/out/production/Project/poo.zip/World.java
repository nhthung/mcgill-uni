import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.BorderFactory;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

public class World {
    private Item[][] world;
    private ArrayList<Item> autonomousItems;
    private int maxRow, maxCol, itemCount;

    private JFrame window;
    private JPanel container;

    World(int rows, int columns) {
        if (rows < 1 || columns < 1)
            throw new IllegalArgumentException("Width and height must be at least 1.");

        maxRow = rows - 1;
        maxCol = columns - 1;
        this.itemCount = 0;

        world = new Item[rows][columns];

        autonomousItems = new ArrayList<>();

        window = new JFrame("Big treats for good dogs!");
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setMinimumSize(new Dimension((800/rows)*columns, 800));

        container = new JPanel(new GridLayout(rows, columns));
        container.setBackground(new Color(217,240,255));

        window.add(container);

        window.setVisible(true);
    }

    public void step() {
        int nextStep;
        int row, col;

        for (Item item: autonomousItems) {
            row = item.getX();
            col = item.getY();

            nextStep = item.getDirection( getPossibleDirs(Item.DIRECTION_MASK, row, col) );

            nextStep = bump(nextStep, row, col);

            item.setNextStep(nextStep);

            item.step();
        }
    }

    public void display() {
        container.removeAll();

        for ( int row = 0; row <= maxRow; row++ ) {
            for ( int col = 0; col <= maxCol; col++ ) {
                Item item = world[row][col];

                JLabel label = new JLabel();
                Color color = new Color(255, 255, 255);

                label.setBorder(BorderFactory.createLineBorder(color));
                label.setHorizontalAlignment(JLabel.CENTER);
                label.setFont(new Font("Helvetica", Font.PLAIN, 28));

                if (item != null) {
                    label.setText(String.valueOf(item.getToken()));

                    if (item instanceof Autonomous)
                        color = new Color(111,115,210);

                    else if (item instanceof Moveable)
                        color = new Color(163,213,255);

                    else if (item instanceof Immovable)
                        color = new Color(118,129,179);

                    label.setForeground(color);
                }

                container.add(label);
            }
        }

        window.pack();

        try {
            Thread.sleep(300);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void add(Item item, int row, int col) throws Exception {
        if (itemCount == (maxRow + 1)*(maxCol + 1))
            throw new Exception("No space left.");

        else if ( row < 0 || row > maxRow || col < 0 || col > maxCol )
            throw new IllegalArgumentException("Position provided is out of this world.");

        else if ( world[row][col] != null )
            throw new IllegalAccessException("Position already occupied!");

        world[row][col] = item;

        if (item instanceof Autonomous)
            autonomousItems.add(item);

        itemCount++;

        item.setWorld(this, row, col);
    }

    private int getPossibleDirs(int directions, final int row, final int col) {
        int possibleDirs = directions;

        if (col + 1 > maxCol || world[row][col+1] instanceof Immovable)
            possibleDirs &= ~Item.DIRECTION_RIGHT;

        if (row + 1 > maxRow || world[row+1][col] instanceof Immovable)
            possibleDirs &= ~Item.DIRECTION_DOWN;

        if (col - 1 < 0 || world[row][col-1] instanceof Immovable)
            possibleDirs &= ~Item.DIRECTION_LEFT;

        if (row - 1 < 0 || world[row-1][col] instanceof Immovable)
            possibleDirs &= ~Item.DIRECTION_UP;

        return possibleDirs;
    }

    private int bump(int nextStep, final int row, final int col) {
        Item nextItem;
        int nextRow = row;
        int nextCol = col;

        switch (nextStep) {
            case Item.DIRECTION_UP: nextRow--; break;
            case Item.DIRECTION_LEFT: nextCol--; break;
            case Item.DIRECTION_DOWN: nextRow++; break;
            case Item.DIRECTION_RIGHT: nextCol++; break;
        }

        if (nextRow < 0 || nextRow > maxRow || nextCol < 0 || nextCol > maxCol)
            return Item.NO_DIRECTION;

        else
            nextItem = world[nextRow][nextCol];

        if (nextItem == null)
            return nextStep;

        else if (nextItem instanceof Autonomous || nextItem instanceof Moveable){
            nextStep = getPossibleDirs(nextStep, nextRow, nextCol);

            if (nextStep == Item.NO_DIRECTION)
                return nextStep;

            else {
                nextStep = bump(nextStep, nextRow, nextCol);

                nextItem.step(nextStep);

                return nextStep;
            }
        }

        else
            return Item.NO_DIRECTION;
    }

    public void updateMap(int nextStep, int row, int col) {
        if ( row < 0 || row > maxRow || col < 0 || col > maxCol )
            throw new IllegalArgumentException("Position provided is out of this world.");

        else if ( world[row][col] == null )
            throw new IllegalArgumentException("No item at this position.");

        else if ( !(world[row][col] instanceof Immovable) ) {
            switch (nextStep) {
                case Item.DIRECTION_RIGHT:
                    world[row][col+1] = world[row][col];
                    world[row][col] = null;
                    break;

                case Item.DIRECTION_UP:
                    world[row-1][col] = world[row][col];
                    world[row][col] = null;
                    break;

                case Item.DIRECTION_LEFT:
                    world[row][col-1] = world[row][col];
                    world[row][col] = null;
                    break;

                case Item.DIRECTION_DOWN:
                    world[row+1][col] = world[row][col];
                    world[row][col] = null;
                    break;
            }
        }
    }

    public void disableCloseOperation() {
        window.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }

    public void closeWindow() {
        window.dispatchEvent(new WindowEvent(window, WindowEvent.WINDOW_CLOSING));
    }
}
