package JavaCool303;

import java.awt.GridLayout;

import javax.swing.JFrame;

public class test {
	public static void main(String[] args) {
		JFrame frame = new JFrame("Big treats for good dogs!");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(400, 800);
		frame.setLayout(new GridLayout(1, 1));
		
		Cool303Root root = new Cool303Root();
		Cool303Container container = new Cool303Container("We had a lot of gay sex");
		
		for(int i = 1; i <= 20; i++) {
			container.add(new Cool303Button(Integer.toString(i)));
		}
		
		root.add(container);
		
		root.applyTheme(new SummerTheme());
		
		frame.add(root);
		
		
		
		frame.setVisible(true);
	}
}
