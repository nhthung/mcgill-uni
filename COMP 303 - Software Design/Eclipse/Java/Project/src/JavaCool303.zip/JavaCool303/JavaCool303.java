// File name: JavaCool303

package JavaCool303;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


/**
 * 
 * @author Le Nhat Hung
 *
 */

public class JavaCool303 {
	private JFrame frame;
	private JPanel panel;
	
	JavaCool303() {
		prepareGUI();
	}
	
	private void prepareGUI(){
		frame = new JFrame("Big treats for good dogs!");
		frame.setSize(400, 400);
		frame.setLayout(new GridLayout(1, 1));
		
		frame.addWindowListener( new WindowAdapter() {
			public void windowClosing(WindowEvent windowEvent) {
				System.exit(0);
			}
		} );
		
		panel = new JPanel();
		panel.setLayout( new FlowLayout() );
		
		frame.add(panel);
	}
	
	private void showWindow() {
		JButton then = new JButton("If home is where the heart is");
		
		then.setActionCommand("what");
		
		then.addActionListener( new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getActionCommand().equals("what"))
					System.out.println("Then my heart's with you, at home");
			}
		} );
		
		panel.add(then);
		
		for ( int i = 1; i <= 20; i++ ) {
			JButton cur = new JButton(Integer.toString(i));
			cur.setActionCommand(Integer.toString(i));
			
			cur.addActionListener( new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (e.getActionCommand().equals( cur.getActionCommand() ))
						System.out.println("We are number " + cur.getActionCommand());
				}
			} );
			
			panel.add(cur);
		}
		
		frame.setVisible(true);
	}
	
	/*
	private class ButtonClickListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			String command = e.getActionCommand();
			
			if (command.equals("what"))
				System.out.println("Then my heart's with you, at home.");
		}
	}*/
	
	public static void main(String[] args) {
		JavaCool303 yaya = new JavaCool303();
		yaya.showWindow();
	}

}