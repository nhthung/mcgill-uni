package JavaCool303;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Cool303Component extends Component {
	void applyTheme() {}
}
