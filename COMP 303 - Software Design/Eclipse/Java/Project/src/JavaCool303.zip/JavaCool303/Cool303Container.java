package JavaCool303;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.util.ArrayList;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JComponent;
import javax.swing.border.Border;
import java.awt.Color;

public class Cool303Container extends JPanel{
	JPanel content;
	
	private ArrayList<Component> components;
	
	Cool303Container() {
		components = new ArrayList<Component>();
		
		this.setLayout(new FlowLayout());
		
		content = this;
	}
	
	Cool303Container(String title) {
		components = new ArrayList<Component>();
		
		this.setLayout(new BorderLayout());
		
		content = new JPanel(new FlowLayout());
		
		this.add(new JLabel(title, (int)JLabel.CENTER_ALIGNMENT), BorderLayout.NORTH);
		this.add(content, BorderLayout.CENTER);
	}
	
	void applyTheme(Cool303Theme theme) {
		Color bgColor = theme.getBackgroundColor();
		
		this.setBackground(bgColor);
		content.setBackground(bgColor);
		
		for (Component c: components) {
			if (c instanceof Cool303Button)
				((Cool303Button)c).applyTheme(theme);
		}
	}
	
	void add(JComponent c) {
		components.add(c);
		content.add(c);
	}
}