package JavaCool303;

import javax.swing.JButton;
import javax.swing.border.Border;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Cool303Button extends JButton {
	//Border border;
	
	Cool303Button() {
		super(" ");
		
		this.addActionListener( new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("This button empty. YEET");
			}
		} );
	}
	
	Cool303Button(String text) {
		super(text);
		
		this.addActionListener( new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println(text);
			}
		} );
	}
	
	void applyTheme(Cool303Theme theme) {
		//this.setBorder(theme.getBorder());
		this.setBackground(theme.getBackgroundColor());
	}

}
