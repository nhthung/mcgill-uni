package JavaCool303;

import java.awt.Color;
import java.util.Random;
import javax.swing.border.Border;
import JavaCool303.Cool303Theme;
import JavaCool303.BubbleBorder;
// define different colors

public class SummerTheme implements Cool303Theme {
	final Random random = new Random(System.currentTimeMillis());
	Border border;
	
	public SummerTheme() {}
	
	private Color generateColor() {
		float h = random.nextFloat();
        float s = random.nextFloat();
        float b = 0.8f + ((1f - 0.8f) * random.nextFloat());
        Color c = Color.getHSBColor(h, s, b);
        border = new BubbleBorder(Color.GRAY, 1, 1);
        return c;
    }

	public Border getBorder() {
		return border;
	}

	public Color getColor() {
		return generateColor();
	}

	public Color getBackgroundColor() {
		return generateColor();
	}
}
