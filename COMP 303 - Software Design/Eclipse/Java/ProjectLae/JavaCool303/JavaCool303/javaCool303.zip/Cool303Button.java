package JavaCool303;
import javax.swing.JButton;

public class Cool303Button extends JButton {

	private static final long serialVersionUID = 1L;
	
	public Cool303Button() {
	}
	
	public Cool303Button(String text) {
		super(text);
	}	
}