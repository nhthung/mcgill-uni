package JavaCool303;

import java.awt.Color;
import javax.swing.border.Border;

public interface Cool303Theme {
	Border getBorder();
	Color getColor();
	Color getBackgroundColor();
}