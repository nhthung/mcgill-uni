General instructions:

Please first copy/move/extract the 260793376 directory into XAMPP's htdocs directory.

Further instructions follow in separate README files in directories PartA and PartB.
