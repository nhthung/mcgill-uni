-- To run using php server on terminal
   
Goto asynchronous dir and run
php -S localhost:9090

You can access it on browser address
localhost:9090

-- To run using XAMPP server

put asynchronous folder in htdocs and point xampp root to it
