#!/bin/bash

if [ -f "$1" ]
then
	var=`grep -o "DOC" "$1"`
	if [ $var ]
	then
		echo "It's there!"
    	chmod 020 $1
	fi
fi