# Artificial Intelligence Local Search Algorithms

*Part of assignment 1 of COMP 424 Artificial Intelligence. Compares Hill Climbing with varying step sizes with Local Beam search with varying beam widths.*
