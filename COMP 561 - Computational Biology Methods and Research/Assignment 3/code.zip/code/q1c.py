from q1b import gen_gff

gen_gff(
    'Vibrio_vulnificus.ASM74310v1.dna.nonchromosomal.fa',
    'hmm.py',
    'q1c_out.gff3'
)