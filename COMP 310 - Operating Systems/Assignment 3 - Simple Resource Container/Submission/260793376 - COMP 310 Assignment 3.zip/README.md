# COMP 310 Operating Systems - Assignment 3: Simple Resource Container

## General information

The submission includes, in addition to `sr_container.c` and `sr_container_helpers.c`, the following files:

* `README.md`: this file
* `run.sh`

    Bash script which runs `SNR_CONTAINER` with all flags:

    ```
    ./SNR_CONTAINER -m /rootfs/jrootfs -u 1 -H magicianNamedGob -C 1 -s 0 -p 50 -M 1048576 -r "8:0 65536" -w "8:0 65536" -c /bin/bash
    ```

* `sr_container.h`

    Additional variable and macro definitions were added to `sr_container.h`.

The container was tested in the docker container

    260793376_container  

in cs310.cs.mcgill.ca.  

## Testing instructions

### To test the code already in the docker container, do the following:

Enter docker container:

    docker exec -it 260793376_container /bin/bash  

Run `SNR_CONTAINER`:

    cd /home/comp310  
    ./run.sh

### To test the submitted code, do the following:

Outside of docker container, extract the submission to one directory <name\>.  
Copy it into the container using `docker cp`:

    docker cp <name> 260793376_container:/home

Enter docker container:

    docker exec -it 260793376_container /bin/bash

Run `SNR_CONTAINER`:

    cd /home/<name>
    chmod 777 *
    ./run.sh

## Additional instructions for each part

**Parts 1-3:**  
Change the `-m` flag option (root file system) as appropriate for the grading machine.  
Same goes with the maj:min for the blkio `-r` and `-w` flags.  

**Parts 4-5:**  
No additional instructions needed for parts 4 and 5.  
Certain capabilities are disabled and processes that call specific system calls will be killed.  
No mercy will be shown.
