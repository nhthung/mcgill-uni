#!/bin/bash

./SNR_CONTAINER -m /rootfs/jrootfs -u 1 -H magicianNamedGob -C 1 -s 0 -p 50 -M 1048576 -r "8:0 65536" -w "8:0 65536" -c /bin/bash
