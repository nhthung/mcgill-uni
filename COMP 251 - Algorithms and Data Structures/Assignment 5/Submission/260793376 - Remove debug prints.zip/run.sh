#!/bin/bash

javac *.java
java balloon
java islands
java mancala
